package apps.app3;

import apps.App;

public class App3 {

	public static void main(String[] args) {
		App app = new App("src/apps/app3/app3.cfg");
	}
	
}


