package apps.app5;

import apps.App;

public class App5 {

	public static void main(String[] args) {
		App app = new App("src/apps/app5/app5.cfg");
	}
	
}
