package apps.app2;

import apps.App;

public class App2 {

	public static void main(String[] args) {
		App app = new App("src/apps/app2/app2.cfg");
	}
	
}


