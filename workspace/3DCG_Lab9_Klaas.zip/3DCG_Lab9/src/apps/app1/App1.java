package apps.app1;

import apps.App;

public class App1 {

	public static void main(String[] args) {
		App app = new App("src/apps/app1/app1.cfg");
	}
	
}


