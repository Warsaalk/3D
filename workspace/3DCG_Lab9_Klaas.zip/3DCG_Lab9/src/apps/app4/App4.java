package apps.app4;

import apps.App;

public class App4 {

	public static void main(String[] args) {
		App app = new App("src/apps/app4/app4.cfg");
	}
	
}


